"""
Google Search grounding — Vodafone Ireland context.
Falls back to detailed static context if search unavailable.
"""
import structlog
import vertexai
from vertexai.generative_models import GenerativeModel, GenerationConfig
from config import settings

logger = structlog.get_logger()

VODAFONE_IRELAND_CONTEXT = """
COMPANY: VODAFONE IRELAND (you are analysing Vodafone Ireland data)

VODAFONE IRELAND:
- Market leader: ~32% Irish mobile share (~1.66M subscribers)
- Part of Vodafone Group global network
- Services: Mobile, Fixed Broadband, Home Phone, TV, Enterprise/IoT
- 5G coverage: 85% population (market leader)
- Key strengths: enterprise 5G, brand, loyal customer base, network quality

COMPETITORS:
1. Eir — ~28% share (~1.46M subs) — national fibre infrastructure owner, GoMo MVNO
2. Three Ireland — ~22% share (~1.14M subs) — aggressive 5G/data pricing, youth focus
3. Sky Ireland — ~10% share (~520K subs) — TV+broadband+mobile bundle strategy
4. Virgin Media Ireland — ~8% share (~416K subs) — urban cable, sports content
5. GoMo (by Eir) / 48 (by Three) / Tesco Mobile — ~5-6% MVNOs, growing fast

IRELAND MARKET 2026:
- Total mobile: ~5.2M subscribers
- Mobile churn average: 15-18% annually
- Vodafone Ireland churn target: <14%
- Mobile ARPU: €18-22/month industry avg
- Vodafone Ireland ARPU target: €22+/month
- Fixed broadband: ~1.6M households
- 5G adoption: Vodafone leads at 85% population coverage
- Fibre: Eir leads, Vodafone growing via NBI wholesale

MARKET TRENDS 2026:
- Fixed-mobile convergence: bundle adoption +12% YoY
- 5G enterprise services growing (IoT, private networks)
- ARPU pressure from MVNO budget operators
- OTT reducing voice revenue ~8% YoY
- Mobile data consumption up 35% YoY
- eSIM adoption accelerating switching ease
- ComReg oversight on pricing transparency

COMPETITIVE DYNAMICS:
- GoMo no-contract plans taking prepay subscribers from Vodafone
- Three Ireland investing in 5G standalone, aggressive on data pricing
- Sky/Virgin Media bundle pricing squeezing family segment margins
- Vodafone advantage: 5G coverage leadership, enterprise IoT contracts
- Churn battleground: loyalty programmes, device deals, bundle offers

VODAFONE IRELAND STRATEGIC PRIORITIES:
- Defend and grow mobile subscriber base vs Three/MVNOs
- Accelerate 5G upsell and ARPU growth
- Develop fixed-mobile convergence bundles vs Sky/Virgin
- Protect enterprise 5G leadership
- Reduce churn below 14% through loyalty
- Grow SME and enterprise IoT revenue

INTERNAL CHANNELS (typical):
- Retail stores (Vodafone branded)
- Affiliate partners
- Direct sales (telesales, online)
- Enterprise direct sales
- Third-party dealers / indirect

PRODUCT LINES:
- Prepay (PAYG)
- Postpay plans (individual, family)
- SIM-only plans
- Fixed broadband (SIRO/NBI fibre)
- Vodafone TV
- Business/Enterprise plans
- IoT/M2M services
"""


async def get_ireland_market_context() -> str:
    """Try Google Search grounding; fall back to static Vodafone Ireland context."""
    vertexai.init(
        project=settings.GCP_PROJECT_ID,
        location=settings.GCP_LOCATION
    )
    search_prompt = (
        "Vodafone Ireland 2026 subscriber performance vs Eir Three Ireland "
        "Sky Ireland market share churn ARPU 5G latest news"
    )
    gen_config = GenerationConfig(temperature=0.1, max_output_tokens=800)

    # Attempt 1
    try:
        from vertexai.generative_models import Tool, grounding
        model = GenerativeModel(
            model_name=settings.VERTEX_AI_MODEL,
            tools=[Tool.from_google_search_retrieval(grounding.GoogleSearchRetrieval())],
        )
        resp = await model.generate_content_async(search_prompt, generation_config=gen_config)
        logger.info("Google Search grounding success")
        return VODAFONE_IRELAND_CONTEXT + "\n\nLATEST NEWS:\n" + resp.text
    except Exception as e:
        logger.warning("Search attempt 1 failed", error=str(e)[:80])

    # Attempt 2
    try:
        from vertexai.preview.generative_models import (
            GenerativeModel as PM, Tool, grounding
        )
        model = PM(
            model_name=settings.VERTEX_AI_MODEL,
            tools=[Tool.from_google_search_retrieval(grounding.GoogleSearchRetrieval())],
        )
        resp = await model.generate_content_async(search_prompt, generation_config=gen_config)
        logger.info("Google Search grounding success (preview)")
        return VODAFONE_IRELAND_CONTEXT + "\n\nLATEST NEWS:\n" + resp.text
    except Exception as e:
        logger.warning("Search attempt 2 failed", error=str(e)[:80])

    logger.info("Using static Vodafone Ireland context")
    return VODAFONE_IRELAND_CONTEXT
