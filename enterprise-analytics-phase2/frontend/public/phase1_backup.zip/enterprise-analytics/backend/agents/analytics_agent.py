"""
Analytics Agent — Vodafone Ireland.
Always returns AI-generated suggested_questions based on real data.
"""
import json
import structlog
import vertexai
from vertexai.generative_models import GenerativeModel, GenerationConfig
from agents.base_agent import BaseAgent
from services.search_service import get_ireland_market_context
from config import settings

logger = structlog.get_logger()

# ── Analytics Prompt ──────────────────────────────────────────────────────────

ANALYTICS_PROMPT = """You are a Senior Analytics AI for VODAFONE IRELAND.
Vodafone Ireland is the company whose data you are analysing.
Eir, Three Ireland, Sky Ireland, Virgin Media, GoMo are the COMPETITORS.
Never say "Ireland Constellation" — always say "Vodafone Ireland".

REAL BIGQUERY DATA:
{data_summary}

VODAFONE IRELAND MARKET CONTEXT:
{market_context}

USER QUESTION: {query}

Respond with ONLY this exact JSON — no markdown, no preamble:
{{
  "what_happened": "2-3 sentences with EXACT numbers from current_period. Calculate exact variance vs previous_period.",

  "kpis": [
    {{
      "label": "metric name",
      "value": "exact string e.g. 251,634",
      "change": "exact variance e.g. +1,975 / +0.8% vs Apr 2026",
      "trend": "up|down|neutral"
    }}
  ],

  "business_context": "2-3 sentences on Vodafone Ireland health vs ~5.2M Ireland market.",

  "why_it_happened": "3-4 sentences referencing specific dimension values from by_dimensions data.",

  "root_causes": [
    {{
      "driver": "specific dimension value from by_dimensions data",
      "impact": "High|Medium|Low",
      "confidence": 85,
      "detail": "one sentence with actual data values",
      "category": "Internal|External|Market|Competitive"
    }}
  ],

  "market_analysis": {{
    "market_position": "Vodafone Ireland vs Eir (~1.46M,28%), Three Ireland (~1.14M,22%) in ~5.2M market.",
    "market_trends": ["trend 1", "trend 2", "trend 3"],
    "growth_outlook": "2-3 sentences on Ireland telecom trajectory."
  }},

  "competitor_analysis": {{
    "competitive_landscape": "2-3 sentences on Ireland competitive dynamics.",
    "competitors": [
      {{"name": "Eir", "position": "~1.46M subs, ~28% share", "threat_level": "High", "insight": "specific insight"}},
      {{"name": "Three Ireland", "position": "~1.14M subs, ~22% share", "threat_level": "High", "insight": "specific insight"}},
      {{"name": "Sky Ireland", "position": "~520K subs, ~10% share", "threat_level": "Medium", "insight": "specific insight"}},
      {{"name": "GoMo / MVNOs", "position": "~5-6% combined, growing", "threat_level": "Medium", "insight": "budget threat"}}
    ],
    "competitive_advantage": "Vodafone Ireland advantage from data",
    "competitive_risk": "biggest threat"
  }},

  "what_to_do": "3-4 sentences strategic direction based on data patterns.",

  "recommendations": [
    {{
      "action": "specific action from data",
      "type": "Strategic|Tactical|Immediate",
      "priority": "P1",
      "timeline": "Next 30 days",
      "expected_impact": "quantified outcome",
      "detail": "2 sentences with data references."
    }},
    {{
      "action": "second action",
      "type": "Strategic|Tactical|Immediate",
      "priority": "P1",
      "timeline": "Next 60 days",
      "expected_impact": "quantified outcome",
      "detail": "2 sentences."
    }},
    {{
      "action": "third action",
      "type": "Strategic|Tactical|Immediate",
      "priority": "P2",
      "timeline": "Next 90 days",
      "expected_impact": "quantified outcome",
      "detail": "2 sentences."
    }}
  ],

  "risks": [
    {{"risk": "specific risk", "severity": "High|Medium|Low", "mitigation": "mitigation"}},
    {{"risk": "second risk", "severity": "High|Medium|Low", "mitigation": "mitigation"}},
    {{"risk": "third risk", "severity": "Medium|Low", "mitigation": "mitigation"}}
  ],

  "summary_bullets": [
    "• [exact KPI value with variance] — business context with number",
    "• [top driver from by_dimensions] — contribution with number",
    "• [Vodafone Ireland market position] — share of ~5.2M with number",
    "• [competitor insight] — Eir/Three/Sky/GoMo with number",
    "• [top recommendation] — specific action with expected impact"
  ],

  "suggested_questions": [
    "specific follow-up question based on the data dimensions you saw",
    "specific question about a channel or segment in the by_dimensions data",
    "specific question about trend or variance you observed",
    "specific question about competitor or market impact on this metric",
    "specific question about a related metric or product plan"
  ],

  "chart": {{
    "type": "line",
    "title": "Vodafone Ireland - Last 6 Months",
    "data": [{{"label": "period", "value": 0}}]
  }},

  "actions": ["Generate PowerPoint", "Export PDF", "Send Teams Alert", "Save Insight", "Schedule Report"]
}}

CRITICAL RULES:
1. KPI value and change MUST be strings — "251,634" not integer
2. Calculate EXACT variance from current_period vs previous_period rows
3. Root causes MUST reference real dimension values from by_dimensions
4. summary_bullets MUST be exactly 5 items starting with "•"
5. suggested_questions MUST be exactly 5 strings — base them on actual dimensions/channels/segments you saw in the data
6. Chart data from real trend query rows — last 6 months
7. Never fabricate numbers
8. suggested_questions must be specific to what was analysed — not generic"""


# ── Contextual fallback questions ─────────────────────────────────────────────

def _get_contextual_questions(query: str, data: dict = None) -> list:
    """Generate questions based on query topic and actual data dimensions."""
    q = query.lower()

    # Try to extract real dimension names from data
    dim_names = []
    results = (data or {}).get("results", {})
    dim_rows = results.get("by_dimensions", {}).get("rows", [])
    if dim_rows and len(dim_rows) > 0:
        dim_names = list(dim_rows[0].keys())

    # Use real column names if available
    date_col    = next((c for c in dim_names if "date" in c.lower() or "period" in c.lower()), None)
    metric_col  = next((c for c in dim_names if any(x in c.lower() for x in ["count","revenue","arpu","churn"])), None)
    segment_col = next((c for c in dim_names if any(x in c.lower() for x in ["type","segment","group","category","channel"])), None)

    if "subscriber" in q or "count" in q:
        base = [
            f"Which channel had the highest subscriber growth this month?",
            f"What is the churn rate by subscriber type?",
            f"Show Residential vs SME subscriber breakdown for 2026",
            f"Which product plan has the highest subscriber count?",
            f"How does Vodafone Ireland subscriber growth compare to Eir?",
        ]
    elif "revenue" in q or "arpu" in q:
        base = [
            f"Which channel generates the highest revenue per subscriber?",
            f"What is the ARPU trend by product plan for last 6 months?",
            f"Show revenue breakdown by subscriber segment",
            f"Which plans have declining revenue contribution?",
            f"How does Vodafone Ireland ARPU compare to Eir and Three Ireland?",
        ]
    elif "churn" in q:
        base = [
            f"Which product plan has the highest churn rate?",
            f"What is churn by acquisition channel?",
            f"Show churn trend for last 6 months by segment",
            f"Which segment has the best retention rate?",
            f"What is the revenue impact of current churn rate?",
        ]
    elif "channel" in q:
        base = [
            f"What is the subscriber count by channel this month?",
            f"Which channel has the best retention rate?",
            f"Show channel performance trend for 2026",
            f"Which channel drives the most high-value subscribers?",
            f"Compare Affiliate vs Direct channel ARPU",
        ]
    elif "trend" in q or "2026" in q:
        base = [
            f"What drove the biggest month-on-month change in 2026?",
            f"Which segment showed the strongest growth trend?",
            f"Show channel contribution to growth over 2026",
            f"What is the seasonality pattern in subscriber numbers?",
            f"How does 2026 performance compare to 2025?",
        ]
    else:
        base = [
            f"Show subscriber count trend for last 6 months",
            f"Which channel drove the most growth this month?",
            f"What is the churn rate by subscriber segment?",
            f"How does Vodafone Ireland compare to Eir on key metrics?",
            f"Which product plan has the highest subscriber count?",
        ]

    # Personalise with real column names if available
    if segment_col and segment_col.lower() not in ["date", "period"]:
        base[1] = f"Show breakdown by {segment_col} for this metric"

    return base[:5]


# ── Format BQ Data ────────────────────────────────────────────────────────────

def format_data_summary(data: dict) -> str:
    results = data.get("results", {})
    if not results:
        rows = data.get("rows", [])
        sql  = data.get("sql",  "")
        if rows:
            lines = [f"CURRENT DATA ({len(rows)} rows):", f"SQL: {sql[:300]}"]
            for i, row in enumerate(rows[:20]):
                lines.append(f"  {i+1}: {dict(row)}")
            return "\n".join(lines)
        return "No data available."
    lines = []
    for key, result in results.items():
        rows  = result.get("rows",  [])
        sql   = result.get("sql",   "")
        error = result.get("error", "")
        lines.append(f"\n{'═'*45}")
        lines.append(f"QUERY: {key.upper().replace('_',' ')}")
        lines.append(f"SQL: {sql[:250]}")
        lines.append(f"ROWS: {len(rows)}")
        if error:
            lines.append(f"ERROR: {error}")
        elif rows:
            for i, row in enumerate(rows[:25]):
                lines.append(f"  {i+1}: {dict(row)}")
        else:
            lines.append("  No rows returned")
    return "\n".join(lines)


# ── Analytics Agent ───────────────────────────────────────────────────────────

class AnalyticsAgent(BaseAgent):
    agent_id = "analytics"
    label    = "Analytics"

    async def _execute(self, context: dict) -> dict:
        dataset = context.get("dataset_label", "Vodafone Ireland")
        query   = context.get("query", "")
        data    = context.get("data", {})
        history = context.get("history", [])

        data_summary   = format_data_summary(data)
        market_context = await get_ireland_market_context()

        full_prompt = ANALYTICS_PROMPT.format(
            data_summary=data_summary,
            market_context=market_context,
            query=query,
        )

        try:
            vertexai.init(
                project=settings.GCP_PROJECT_ID,
                location=settings.GCP_LOCATION
            )
            model = GenerativeModel(model_name=settings.VERTEX_AI_MODEL)

            # Build conversation history
            contents = []
            for msg in history[-4:]:
                role = "user" if msg["role"] == "user" else "model"
                text = msg["content"] if isinstance(msg["content"], str) else str(msg["content"])
                contents.append({"role": role, "parts": [{"text": text[:400]}]})
            contents.append({"role": "user", "parts": [{"text": full_prompt}]})

            response = await model.generate_content_async(
                contents,
                generation_config=GenerationConfig(
                    temperature=0.2,
                    max_output_tokens=4096,
                ),
            )

            raw = response.text.strip()
            if raw.startswith("```"):
                raw = raw.split("\n", 1)[-1].rsplit("```", 1)[0].strip()

            result = json.loads(raw)

            # ── Force KPI fields to strings ──────────────────────────────────
            for kpi in result.get("kpis", []):
                kpi["value"]  = str(kpi.get("value",  "N/A"))
                kpi["change"] = str(kpi.get("change", "N/A"))
                if not kpi.get("trend"):
                    kpi["trend"] = "neutral"

            # ── Validate and fix suggested_questions ─────────────────────────
            sq = result.get("suggested_questions")
            valid_sq = [str(q).strip() for q in (sq or []) if q and str(q).strip()]

            if len(valid_sq) < 5:
                logger.info("AI returned insufficient questions, generating via dedicated call",
                            got=len(valid_sq))
                try:
                    # Dedicated question generation call using real data context
                    dim_rows = data.get("results", {}).get("by_dimensions", {}).get("rows", [])
                    dim_sample = str(dim_rows[:5]) if dim_rows else "no dimensional data"

                    q_prompt = f"""You are analysing Vodafone Ireland data.

User just asked: "{query}"

The BigQuery data returned these dimension breakdowns:
{dim_sample}

Generate exactly 5 specific follow-up questions a Vodafone Ireland business analyst would ask next.
Base questions on the actual dimensions/channels/segments/plans visible in the data above.
Return ONLY a valid JSON array of 5 question strings. Nothing else.
["question 1", "question 2", "question 3", "question 4", "question 5"]"""

                    q_resp = await model.generate_content_async(
                        q_prompt,
                        generation_config=GenerationConfig(
                            temperature=0.4,
                            max_output_tokens=400,
                        ),
                    )
                    q_raw = q_resp.text.strip()
                    q_raw = q_raw.replace("```json","").replace("```","").strip()
                    generated = json.loads(q_raw)
                    if isinstance(generated, list) and len(generated) > 0:
                        valid_sq = [str(q) for q in generated if q][:5]
                        logger.info("Questions generated via dedicated call", count=len(valid_sq))
                    else:
                        raise ValueError("Invalid format")
                except Exception as qe:
                    logger.warning("Dedicated question call failed, using contextual defaults",
                                   error=str(qe))
                    valid_sq = _get_contextual_questions(query, data)

            # Pad to exactly 5 if needed
            defaults = _get_contextual_questions(query, data)
            while len(valid_sq) < 5:
                candidate = defaults[len(valid_sq)]
                if candidate not in valid_sq:
                    valid_sq.append(candidate)

            result["suggested_questions"] = valid_sq[:5]

            # ── Validate summary_bullets ─────────────────────────────────────
            sb = result.get("summary_bullets")
            result["summary_bullets"] = [str(b) for b in (sb or []) if b]

            context["analytics_result"] = result
            logger.info(
                "Analytics complete",
                query=query[:60],
                kpis=len(result.get("kpis", [])),
                bullets=len(result.get("summary_bullets", [])),
                questions=len(result.get("suggested_questions", [])),
            )

        except json.JSONDecodeError as e:
            logger.error("JSON parse error", error=str(e))
            context["analytics_result"] = _fallback(data, query)
        except Exception as e:
            logger.error("Analytics error", error=str(e))
            context["analytics_result"] = _fallback(data, query)

        return context


# ── Fallback Response ─────────────────────────────────────────────────────────

def _fallback(data: dict, query: str = "") -> dict:
    rows    = data.get("rows", [])
    results = data.get("results", {})
    val = "N/A"
    if results.get("current_period", {}).get("rows"):
        r = results["current_period"]["rows"][0]
        v = list(r.values())[-1]
        val = f"{v:,}" if isinstance(v, (int, float)) else str(v)
    elif rows:
        v = list(rows[0].values())[-1]
        val = f"{v:,}" if isinstance(v, (int, float)) else str(v)

    return {
        "what_happened": f"Vodafone Ireland data retrieved for: {query}. Value: {val}.",
        "kpis": [{"label": "Metric", "value": val, "change": "N/A", "trend": "neutral"}],
        "business_context": "Vodafone Ireland holds ~32% of the Irish mobile market (~1.66M subscribers).",
        "why_it_happened": "Review dimensional data for channel, segment and product breakdown.",
        "root_causes": [
            {"driver": "Data retrieved", "impact": "High", "confidence": 70,
             "detail": "BigQuery returned data successfully.", "category": "Internal"}
        ],
        "market_analysis": {
            "market_position": "Vodafone Ireland leads with ~32% share (~1.66M subscribers) in ~5.2M Irish mobile market.",
            "market_trends": [
                "5G coverage: Vodafone Ireland leads at 85% population coverage",
                "Fixed-mobile convergence bundle adoption +12% YoY",
                "ARPU pressure from GoMo and budget MVNOs"
            ],
            "growth_outlook": "Ireland telecom growing ~1.8% YoY. 5G enterprise and fibre are key drivers through 2027."
        },
        "competitor_analysis": {
            "competitive_landscape": "Vodafone Ireland leads. Eir (~28%), Three Ireland (~22%), Sky (~10%), Virgin (~8%).",
            "competitors": [
                {"name": "Eir", "position": "~1.46M subs, 28%", "threat_level": "High",
                 "insight": "National fibre owner; GoMo MVNO disrupting budget segment"},
                {"name": "Three Ireland", "position": "~1.14M subs, 22%", "threat_level": "High",
                 "insight": "Aggressive 5G pricing targeting youth and data-heavy users"},
                {"name": "Sky Ireland", "position": "~520K subs, 10%", "threat_level": "Medium",
                 "insight": "Bundle pricing with TV content challenging family plans"},
                {"name": "GoMo / MVNOs", "position": "~5-6% combined", "threat_level": "Medium",
                 "insight": "Budget no-contract plans eroding Vodafone prepay base"}
            ],
            "competitive_advantage": "Vodafone leads in 5G coverage (85%), enterprise IoT and brand trust",
            "competitive_risk": "Three Ireland 5G investment and GoMo pricing threatening retention"
        },
        "what_to_do": "Focus on channel optimisation and retention. Counter MVNO threat with competitive SIM-only offers.",
        "recommendations": [
            {"action": "Analyse subscriber churn by channel", "type": "Immediate", "priority": "P1",
             "timeline": "Next 30 days", "expected_impact": "Identify top 3 churn drivers",
             "detail": "Break down subscriber movement by channel. Focus retention on highest-LTV segments."},
            {"action": "Counter GoMo/MVNO budget threat", "type": "Tactical", "priority": "P1",
             "timeline": "Next 60 days", "expected_impact": "Retain 5,000+ at-risk subscribers",
             "detail": "Develop competitive SIM-only proposition targeting budget segment."},
            {"action": "5G upsell for existing base", "type": "Strategic", "priority": "P2",
             "timeline": "Next 90 days", "expected_impact": "+€2-3 ARPU per converted subscriber",
             "detail": "Target 4G subscribers in 5G areas. Leverage 85% coverage advantage."}
        ],
        "risks": [
            {"risk": "Three Ireland 5G pricing undercutting postpay",
             "severity": "High", "mitigation": "Reinforce 5G quality superiority in marketing"},
            {"risk": "GoMo MVNO eroding prepay base",
             "severity": "High", "mitigation": "Launch competitive budget SIM-only proposition"},
            {"risk": "Sky Ireland bundle pricing attracting families",
             "severity": "Medium", "mitigation": "Develop Vodafone TV+Mobile+Broadband bundle"}
        ],
        "summary_bullets": [
            f"• Current value: {val} — review dimensional data for full context",
            "• Vodafone Ireland leads Irish market with ~1.66M subscribers (~32% share)",
            "• Eir ~1.46M (28%), Three Ireland ~1.14M (22%), Sky ~520K (10%)",
            "• GoMo and Three Ireland aggressive pricing are top competitive threats",
            "• Priority: channel breakdown analysis and retention programme vs MVNOs"
        ],
        "suggested_questions": _get_contextual_questions(query, data),
        "chart": None,
        "actions": ["Generate PowerPoint", "Export PDF", "Send Teams Alert", "Save Insight", "Schedule Report"]
    }
