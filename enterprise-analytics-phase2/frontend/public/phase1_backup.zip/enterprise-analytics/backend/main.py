"""
Enterprise Agentic Analytics Platform — FastAPI Backend
Vertex AI / Google Cloud production entry point
"""
import structlog
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware

from config import settings
from routers import chat, insights, datasets, health
from services.vertex_client import init_vertex_ai

logger = structlog.get_logger()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup / shutdown lifecycle."""
    logger.info("Starting Enterprise Analytics Platform", env=settings.ENVIRONMENT)
    init_vertex_ai()
    yield
    logger.info("Shutting down")


app = FastAPI(
    title="Enterprise Agentic Analytics Platform",
    description="Multi-agent AI analytics powered by Vertex AI Gemini",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/api/docs" if settings.ENVIRONMENT != "production" else None,
    redoc_url=None,
)

# ── Middleware ────────────────────────────────────────────────────────────────

app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ───────────────────────────────────────────────────────────────────

app.include_router(health.router, prefix="/api/v1")
app.include_router(chat.router, prefix="/api/v1")
app.include_router(insights.router, prefix="/api/v1")
app.include_router(datasets.router, prefix="/api/v1")
