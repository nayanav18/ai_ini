"""Chat router."""
from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
import structlog
from models.schemas import ChatRequest
from agents.orchestrator import run_pipeline
router = APIRouter(tags=["chat"])
logger = structlog.get_logger()

@router.post("/chat")
async def chat(request: ChatRequest):
   logger.info("Chat request", query=request.query[:80], dataset=request.dataset_id)
   try:
       result = await run_pipeline(
           query=request.query,
           dataset_id=request.dataset_id,
           conversation_id=request.conversation_id,
           history=[m.model_dump() for m in request.history],
       )
       # Serialize — includes ALL fields from AI
       data = result.model_dump(mode="json")
       logger.info(
           "Response ready",
           questions=data.get("suggested_questions"),
           bullets=len(data.get("summary_bullets") or []),
       )
       return JSONResponse(content=data)
   except Exception as e:
       logger.error("Pipeline error", error=str(e))
       raise HTTPException(status_code=500, detail=str(e))