import { useState } from "react";
import Sidebar from "./components/Sidebar";
import ChatView from "./components/ChatView";
import InsightsView from "./components/InsightsView";
import DashboardView from "./components/DashboardView";
import { useChat } from "./hooks/useChat";
import { DATASETS, uid } from "./utils/helpers";
import { api } from "./utils/api";

export default function App() {
  const [activeNav, setActiveNav] = useState("chat");
  const [selectedDataset, setSelectedDataset] = useState(DATASETS[0]);
  const [savedInsights, setSavedInsights] = useState([]);

  const {
    conversations, activeConv, activeConvId,
    messages, loading, agentSteps,
    newChat, openConv, sendMessage,
  } = useChat({ selectedDataset });

  const handleSaveInsight = (msg) => {
    const insight = {
      id: uid(),
      query: msg.query || "Untitled",
      dataset: msg.dataset || selectedDataset.label,
      data: msg.content,
      ts: Date.now(),
    };
    setSavedInsights((prev) => [insight, ...prev]);

    // Also persist to backend if available
    api.saveInsight({
      conversation_id: activeConvId,
      query: insight.query,
      analytics: msg.content,
      dataset_id: selectedDataset.id,
    }).catch(() => {/* backend optional */});
  };

  const handleDeleteInsight = (id) => {
    setSavedInsights((prev) => prev.filter((ins) => ins.id !== id));
    api.deleteInsight(id).catch(() => {});
  };

  const handleSend = (query) => {
    if (!activeConvId) newChat();
    sendMessage(query);
  };

  return (
    <div style={{ display: "flex", height: "100vh", overflow: "hidden", background: "#060d1a" }}>
      <style>{`
        @keyframes spin  { to { transform: rotate(360deg); } }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
        * { box-sizing: border-box; }
        input::placeholder { color: #374151; }
        button { transition: all 0.15s; }
      `}</style>

      <Sidebar
        activeNav={activeNav}
        setActiveNav={(nav) => {
          setActiveNav(nav);
          if (nav === "chat" && !activeConvId && conversations.length > 0) {
            openConv(conversations[0].id);
          }
        }}
        selectedDataset={selectedDataset}
        setSelectedDataset={setSelectedDataset}
        conversations={conversations}
        activeConvId={activeConvId}
        openConv={openConv}
        newChat={newChat}
        savedInsightsCount={savedInsights.length}
      />

      <main style={{ flex: 1, overflow: "hidden", display: "flex", flexDirection: "column" }}>
        {(activeNav === "chat" || activeNav === "history") && (
          <ChatView
            messages={messages}
            loading={loading}
            agentSteps={agentSteps}
            activeConv={activeConv}
            selectedDataset={selectedDataset}
            onSend={handleSend}
            onNewChat={newChat}
            onSaveInsight={handleSaveInsight}
          />
        )}
        {activeNav === "insights" && (
          <div style={{ flex: 1, overflowY: "auto" }}>
            <InsightsView insights={savedInsights} onDelete={handleDeleteInsight} />
          </div>
        )}
        {activeNav === "dashboards" && (
          <div style={{ flex: 1, overflowY: "auto" }}>
            <DashboardView insights={savedInsights} />
          </div>
        )}
      </main>
    </div>
  );
}
